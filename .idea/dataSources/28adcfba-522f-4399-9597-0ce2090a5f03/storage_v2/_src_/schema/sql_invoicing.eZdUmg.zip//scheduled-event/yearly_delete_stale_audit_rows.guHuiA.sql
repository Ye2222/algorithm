create definer = root@localhost event yearly_delete_stale_audit_rows on schedule
    every '1' YEAR
        starts '2021-01-01 00:00:00'
        ends '2029-01-01 00:00:00'
    enable
    do
    BEGIN
    DELETE FROM payments_audit
    WHERE action_date < NOW() - INTERVAL 1 YEAR;
END;

