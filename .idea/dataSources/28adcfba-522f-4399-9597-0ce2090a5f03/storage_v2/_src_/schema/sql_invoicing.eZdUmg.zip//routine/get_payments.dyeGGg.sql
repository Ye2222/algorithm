create
    definer = root@localhost procedure get_payments(IN cid int, IN pid tinyint)
BEGIN
    SELECT client_id, amount
    FROM payments p
    WHERE p.payment_method = IFNULL(pid, p.payment_method)
      and p.client_id = IFNULL(cid, p.client_id);
end;

