create definer = root@localhost trigger fired_after_payment
    after delete
    on payments
    for each row
BEGIN
    UPDATE invoices
    SET payment_total = payment_total - OLD.amount
    WHERE client_id = OLD.client_id;
end;

