create definer = root@localhost view invoice_with_balance as
select `sql_invoicing`.`invoices`.`invoice_id`                                                   AS `invoice_id`,
       `sql_invoicing`.`invoices`.`number`                                                       AS `number`,
       `sql_invoicing`.`invoices`.`client_id`                                                    AS `client_id`,
       `sql_invoicing`.`invoices`.`invoice_total`                                                AS `invoice_total`,
       `sql_invoicing`.`invoices`.`payment_total`                                                AS `payment_total`,
       (`sql_invoicing`.`invoices`.`invoice_total` - `sql_invoicing`.`invoices`.`payment_total`) AS `balance`,
       `sql_invoicing`.`invoices`.`invoice_date`                                                 AS `invoice_date`,
       `sql_invoicing`.`invoices`.`due_date`                                                     AS `due_date`,
       `sql_invoicing`.`invoices`.`payment_date`                                                 AS `payment_date`
from `sql_invoicing`.`invoices`
where ((`sql_invoicing`.`invoices`.`invoice_total` - `sql_invoicing`.`invoices`.`payment_total`) > 0);

