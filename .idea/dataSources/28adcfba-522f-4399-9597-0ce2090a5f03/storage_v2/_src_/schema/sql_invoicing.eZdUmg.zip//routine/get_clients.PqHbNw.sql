create
    definer = root@localhost procedure get_clients()
BEGIN
    SELECT * FROM clients;
end;

