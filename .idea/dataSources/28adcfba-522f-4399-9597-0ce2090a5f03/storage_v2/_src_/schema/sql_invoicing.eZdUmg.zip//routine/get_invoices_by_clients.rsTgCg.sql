create
    definer = root@localhost procedure get_invoices_by_clients(IN cid int)
BEGIN
    SELECT *
    FROM invoices i
    WHERE i.client_id = IFNULL(cid, i.client_id);
end;

