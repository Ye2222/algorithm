create
    definer = root@localhost procedure get_unpaid_invoices_for_client(IN client_id int, OUT invoices_count int,
                                                                      OUT invoices_total decimal(9, 2))
BEGIN
    SELECT COUNT(*), SUM(invoice_total)
    INTO invoices_count, invoices_total
        FROM invoices i
    WHERE i.client_id = client_id
    AND payment_total = 0;
end;

