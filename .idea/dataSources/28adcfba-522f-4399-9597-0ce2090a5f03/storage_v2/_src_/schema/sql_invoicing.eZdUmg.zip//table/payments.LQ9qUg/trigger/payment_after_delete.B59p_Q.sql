create definer = root@localhost trigger payment_after_delete
    after delete
    on payments
    for each row
BEGIN
    UPDATE invoices
    SET payment_total = payment_total - OLD.amount
    WHERE invoice_id = OLD.invoice_id;

    INSERT INTO payments_audit
    values (OLD.client_id, OLD.date, OLD.amount, 'DELETE', NOW());
end;

