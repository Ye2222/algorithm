create
    definer = root@localhost procedure make_payments(IN iid int, IN payment_amount decimal(9, 2), IN payment_date date)
BEGIN
    UPDATE invoices i
    SET
        i.payment_total = payment_amount,
        i.payment_date = payment_date
    WHERE i.invoice_id = iid;
end;

