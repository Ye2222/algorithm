create
    definer = root@localhost procedure get_clients_by_state(IN state varchar(4))
BEGIN
    SELECT *
    FROM clients
    WHERE clients.state = state;
end;

